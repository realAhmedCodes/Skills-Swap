<div className={styles.navbar}>
      <div className={styles.links}>
        <Link to="/">Home</Link>
        <Link to="/Job_Info">Post Job</Link>
        <Link to="/Register">Register </Link>
        <Link to="/Login">Login </Link>
        <div>
          <div className={styles.login_btn}>
            <div className={styles.profile}>
              <img
                className={styles.profile_img}
                src={user}
                alt="user image"
                onClick={showMenu}
              />
            </div>
            {show === true ? (
              <div className={styles.menu}>
                <p onClick={listFunc}>Profile</p>
                {role === "employer" ? (
                  <p onClick={candidatesPage}>Candidates</p>
                ) : (
                  ""
                )}
                {role === "user" ? (
                  <>
                    <p onClick={savedJobsPage}>Saved Jobs</p>
                    <p onClick={appliedJobsPage}>Applied Jobs</p>
                  </>
                ) : (
                  ""
                )}
                <p onClick={logout}>Log Out</p>
              </div>
            ) : (
              ""
            )}
          </div>
        </div>
      </div>
    </div>